---
name: Playful Creator
colors:
  surface: '#fef8f1'
  surface-dim: '#dfd9d2'
  surface-bright: '#fef8f1'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f9f3ec'
  surface-container: '#f3ede6'
  surface-container-high: '#ede7e0'
  surface-container-highest: '#e7e2db'
  on-surface: '#1d1b17'
  on-surface-variant: '#54433a'
  inverse-surface: '#32302c'
  inverse-on-surface: '#f6f0e9'
  outline: '#877369'
  outline-variant: '#dac1b6'
  surface-tint: '#954919'
  primary: '#954919'
  on-primary: '#ffffff'
  primary-container: '#ff9d66'
  on-primary-container: '#773302'
  inverse-primary: '#ffb68f'
  secondary: '#006780'
  on-secondary: '#ffffff'
  secondary-container: '#5ed8ff'
  on-secondary-container: '#005c72'
  tertiary: '#785a00'
  on-tertiary: '#ffffff'
  tertiary-container: '#dbb048'
  on-tertiary-container: '#5b4300'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#ffdbca'
  primary-fixed-dim: '#ffb68f'
  on-primary-fixed: '#331100'
  on-primary-fixed-variant: '#773202'
  secondary-fixed: '#b7eaff'
  secondary-fixed-dim: '#5bd5fc'
  on-secondary-fixed: '#001f28'
  on-secondary-fixed-variant: '#004e61'
  tertiary-fixed: '#ffdf9b'
  tertiary-fixed-dim: '#edc157'
  on-tertiary-fixed: '#251a00'
  on-tertiary-fixed-variant: '#5b4300'
  background: '#fef8f1'
  on-background: '#1d1b17'
  surface-variant: '#e7e2db'
typography:
  headline-xl:
    fontFamily: Quicksand
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 56px
  headline-lg:
    fontFamily: Quicksand
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
  headline-lg-mobile:
    fontFamily: Quicksand
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 36px
  body-lg:
    fontFamily: Quicksand
    fontSize: 20px
    fontWeight: '500'
    lineHeight: 30px
  body-md:
    fontFamily: Quicksand
    fontSize: 18px
    fontWeight: '500'
    lineHeight: 26px
  label-bold:
    fontFamily: Quicksand
    fontSize: 16px
    fontWeight: '700'
    lineHeight: 20px
    letterSpacing: 0.02em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  unit: 8px
  touch-target-min: 64px
  margin-page: 32px
  gutter: 16px
  stack-gap: 24px
---

## Brand & Style

This design system is built to empower young creators with a "Simple & Playful" aesthetic. The brand personality is encouraging, energetic, and high-energy, moving away from utility toward an environment that feels like a digital toy box. 

The visual style blends **Tactile / Skeuomorphic** elements with **High-Contrast / Bold** modern interfaces. UI elements are "chunky" and physically suggestive, using soft, heavy shadows to indicate depth and "tappability" for developing motor skills. The emotional goal is to spark curiosity and provide instant, joyful feedback. All communication uses simple, action-oriented language that speaks directly to the child.

## Colors

The palette is vibrant and saturated to capture attention and differentiate distinct interactive zones.

- **Energetic Orange (Primary):** Used for the main "action" path (Next, Start, Paint).
- **Sky Blue (Secondary):** Used for supporting actions, progress indicators, and interactive chips.
- **Sunny Yellow (Tertiary):** Used for celebratory highlights, stars, and accents.
- **Paper Cream (Neutral):** A soft, warm off-white background that reduces eye strain compared to pure white and provides a "craft paper" feel.

High-contrast text (primarily deep charcoal #333333) ensures maximum readability against these bright backgrounds.

## Typography

Typography is exceptionally large and rounded to match the playful brand. **Quicksand** is the sole typeface, chosen for its friendly, approachable letterforms and terminal roundness.

Headlines should be used sparingly, focusing on one primary question or instruction per screen. Body text is limited to short, encouraging phrases. On mobile devices, font sizes maintain a high floor to ensure legibility even when the device is held at a distance.

## Layout & Spacing

The layout philosophy centers on a **Single-Column Focus**. To prevent cognitive overload, only one primary task or decision is presented at a time.

- **Grid:** A simplified 4-column grid for mobile and 8-column grid for tablet/desktop. 
- **Whitespace:** Extremely generous margins and vertical padding to isolate interactive elements.
- **Touch Targets:** All interactive areas (buttons, chips) have a minimum height of 64px to accommodate small fingers and imprecise tapping.
- **Reflow:** On smaller screens, horizontal lists (like character attributes) reflow into vertical stacks or wrapped flex-rows with high vertical gutters.

## Elevation & Depth

Visual hierarchy is achieved through **Tonal Layers** and **Ambient Shadows**. 

Containers (cards) use a subtle white surface with a very soft, diffused shadow to "lift" them from the cream background. Interactive elements like buttons use a more pronounced "chunky" shadow (e.g., 0px 4px 0px rgba(0,0,0,0.1)) to simulate a physical button that can be pressed down. 

When a button is "tapped," it should visually shift downward (transform: translateY(2px)) and reduce its shadow to provide tactile feedback.

## Shapes

The shape language is consistently **Rounded**. There are no sharp corners in the design system. 

Standard components use a 16px (1rem) corner radius. Larger containers or "hero" cards use 32px (2rem) to maintain a soft, friendly silhouette. Progress dots and small chips may use pill-shaped (fully rounded) geometry to distinguish them from primary action buttons.

## Components

- **Chunky Buttons:** The primary action component. Large, bold background color, centered text, and a thick bottom border or shadow. Always include an icon (emoji or simple SVG) to assist pre-readers.
- **Selection Chips:** Used for "Tell us about your character." White backgrounds with a colored border that fills in when selected. Each chip must contain an emoji.
- **Instruction Cards:** Large white containers with 32px padding. Used to house the main interaction of the screen (e.g., the camera preview or the drawing canvas).
- **Progress Steppers:** Simple colored dots at the top of the screen. The active step is larger and more vibrant; completed steps are smaller and muted.
- **Input Fields:** Oversized text inputs with a thick 2px colored border. Placeholder text should be phrased as a prompt (e.g., "Type a name...").
- **Success Modals:** Full-screen or large centered overlays that use celebratory emojis and bright Tertiary Yellow accents to reward completion.